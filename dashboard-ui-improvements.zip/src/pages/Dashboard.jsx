'use client';

import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { NewScanModal } from '../components/NewScanModal';
import { DetailDrawer } from '../components/DetailDrawer';

const Dashboard = () => {
  const [scans, setScans] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedFinding, setSelectedFinding] = useState(null);
  const [findings, setFindings] = useState([]);
  const [activeScanId, setActiveScanId] = useState(null);

  const fetchScans = useCallback(async () => {
    try {
      const res = await axios.get('http://localhost:8000/api/scans');
      console.log("Data received from backend:", res.data);
      setScans(res.data);
    } catch (err) {
      console.error("Fetch error:", err);
    }
  }, []);

  useEffect(() => {
    fetchScans();
    const interval = setInterval(fetchScans, 5000);
    return () => clearInterval(interval);
  }, [fetchScans]);

  const handleUpload = async (file, config, taskName, taskDescription) => {
    if (!file) return;
    setShowModal(false);
    
    const formData = new FormData();
    formData.append('file', file);
    formData.append('config', config);
    formData.append('task_name', taskName);
    formData.append('task_description', taskDescription);
    
    try {
      const res = await axios.post('http://localhost:8000/api/scans', formData);
      console.log("Upload Response:", res.data);
      fetchScans(); 
    } catch (err) {
      console.error("Upload Error:", err);
      alert("Upload failed. Check backend status.");
    }
  };

  const loadFindings = async (scanId) => {
    setActiveScanId(scanId);
    setFindings([]); 
    try {
      const res = await axios.get(`http://localhost:8000/api/results/${scanId}/findings`);
      setFindings(res.data);
    } catch (err) { 
      console.error("Error loading findings:", err); 
    }
  };

  const getSeverityStyles = (severity) => {
    const s = severity?.toLowerCase();
    if (s === 'critical') return 'bg-red-500/20 text-red-400 border-red-500/30';
    if (s === 'high') return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
    if (s === 'medium') return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
    if (s === 'low') return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
  };

  const getStatusStyles = (status) => {
    const s = status?.toLowerCase();
    if (s === 'completed') return 'bg-emerald-500/20 text-emerald-400';
    if (s === 'running') return 'bg-cyan-500/20 text-cyan-400';
    if (s === 'failed') return 'bg-red-500/20 text-red-400';
    return 'bg-slate-500/20 text-slate-400';
  };

  return (
    <div className={`min-h-screen bg-slate-950 transition-all duration-300 ${selectedFinding ? 'mr-[520px]' : ''}`}>
      {/* Background Pattern */}
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-slate-950 pointer-events-none" />
      <div className="fixed inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%23334155%22%20fill-opacity%3D%220.05%22%3E%3Cpath%20d%3D%22M36%2034v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6%2034v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6%204V0H4v4H0v2h4v4h2V6h4V4H6z%22%2F%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E')] opacity-50 pointer-events-none" />

      <div className="relative p-8">
        {/* Header Section */}
        <header className="flex items-center justify-between mb-10">
          <div>
            <h1 className="text-3xl font-bold text-white mb-1 tracking-tight">
              Security Center
            </h1>
            <p className="text-slate-500 text-sm">
              Automated Vulnerability Assessment & AI-Powered Triage
            </p>
          </div>
          <button 
            onClick={() => setShowModal(true)} 
            className="group relative bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white px-6 py-3 rounded-xl font-semibold shadow-lg shadow-cyan-500/25 transition-all duration-200 active:scale-95 flex items-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            New Scan
            <div className="absolute inset-0 rounded-xl bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity" />
          </button>
        </header>

        <div className="grid grid-cols-12 gap-8">
          {/* Left Column: Scan History */}
          <section className="col-span-4">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Recent Scans
              </h2>
              <span className="text-xs text-slate-600 bg-slate-800/50 px-2 py-1 rounded-lg">
                {scans.length} total
              </span>
            </div>
            
            <div className="space-y-3 max-h-[calc(100vh-200px)] overflow-y-auto pr-2 scrollbar-thin">
              {scans.length === 0 && (
                <div className="text-center py-16 bg-slate-900/50 rounded-2xl border border-slate-800">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-slate-800 flex items-center justify-center">
                    <svg className="w-8 h-8 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                  </div>
                  <p className="text-slate-500 text-sm">No scans performed yet</p>
                  <p className="text-slate-600 text-xs mt-1">Start a new scan to begin</p>
                </div>
              )}

              {scans.map(scan => (
                <div
                  key={scan.id}
                  onClick={() => loadFindings(scan.id)}
                  className={`p-5 rounded-2xl border cursor-pointer transition-all duration-200 ${
                    activeScanId === scan.id 
                      ? 'bg-slate-800/80 border-cyan-500/50 shadow-lg shadow-cyan-500/10' 
                      : 'bg-slate-900/50 border-slate-800 hover:bg-slate-800/50 hover:border-slate-700'
                  }`}
                >
                  {/* Top Row */}
                  <div className="flex items-center justify-between mb-3">
                    <code className="text-xs font-mono text-slate-500 bg-slate-800 px-2 py-1 rounded">
                      #{scan.id.slice(0,8)}
                    </code>
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-lg ${getStatusStyles(scan.status)}`}>
                      {scan.status}
                    </span>
                  </div>

                  {/* Task Name */}
                  <h3 className="font-semibold text-white mb-2 line-clamp-1">
                    {scan.task_name || "Unnamed Task"}
                  </h3>

                  {/* Config */}
                  <p className="text-xs text-slate-500 mb-4 flex items-center gap-1">
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                    </svg>
                    {scan.config_profile}
                  </p>

                  {/* Bottom Stats */}
                  <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                    <div className="flex items-center gap-4">
                      <div>
                        <p className="text-[10px] text-slate-600 uppercase tracking-wider">Findings</p>
                        <p className={`text-lg font-bold ${scan.total_findings > 0 ? 'text-orange-400' : 'text-emerald-400'}`}>
                          {scan.total_findings}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] text-slate-600 uppercase tracking-wider">Date</p>
                      <p className="text-sm text-slate-400">
                        {new Date(scan.scanned_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Right Column: Findings Detail */}
          <section className="col-span-8">
            {activeScanId ? (
              <>
                <div className="flex items-center justify-between mb-5">
                  <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-2">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                    Results for <code className="ml-1 font-mono text-cyan-400">#{activeScanId.slice(0,8)}</code>
                  </h2>
                  <span className="text-xs text-slate-600 bg-slate-800/50 px-2 py-1 rounded-lg">
                    {findings.length} vulnerabilities
                  </span>
                </div>

                {findings.length === 0 ? (
                  <div className="text-center py-20 bg-slate-900/50 rounded-2xl border border-slate-800">
                    <div className={`w-20 h-20 mx-auto mb-4 rounded-full flex items-center justify-center ${
                      scans.find(s => s.id === activeScanId)?.status === 'running' 
                        ? 'bg-cyan-500/20' 
                        : 'bg-emerald-500/20'
                    }`}>
                      {scans.find(s => s.id === activeScanId)?.status === 'running' ? (
                        <svg className="w-10 h-10 text-cyan-400 animate-spin" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                      ) : (
                        <svg className="w-10 h-10 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                        </svg>
                      )}
                    </div>
                    <p className="text-slate-400 font-medium">
                      {scans.find(s => s.id === activeScanId)?.status === 'running' 
                        ? "Scan in Progress..." 
                        : "No Vulnerabilities Detected"}
                    </p>
                    <p className="text-slate-600 text-sm mt-1">
                      {scans.find(s => s.id === activeScanId)?.status === 'running' 
                        ? "Please wait while we analyze your code" 
                        : "Your codebase appears to be secure"}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-[calc(100vh-200px)] overflow-y-auto pr-2">
                    {findings.map(f => (
                      <div
                        key={f.id}
                        onClick={() => setSelectedFinding(f)}
                        className="group bg-slate-900/50 border border-slate-800 p-5 rounded-2xl hover:bg-slate-800/50 hover:border-slate-700 transition-all duration-200 cursor-pointer"
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-2">
                              <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-md border ${getSeverityStyles(f.severity)}`}>
                                {f.severity}
                              </span>
                              <span className="text-xs text-slate-500 bg-slate-800 px-2 py-1 rounded">
                                {f.vulnerability_class || "General"}
                              </span>
                            </div>
                            <h3 className="font-semibold text-white mb-2 line-clamp-2 group-hover:text-cyan-300 transition-colors">
                              {f.title}
                            </h3>
                            <p className="text-xs text-slate-500 flex items-center gap-2">
                              <code className="text-cyan-400/70 font-mono">
                                {f.file_path.split('/').pop()}
                              </code>
                              <span className="text-slate-700">•</span>
                              <span>Line {f.line_number}</span>
                            </p>
                          </div>
                          <div className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                            <span className="text-cyan-400 text-sm font-medium flex items-center gap-1">
                              View
                              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                              </svg>
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <div className="h-full flex items-center justify-center">
                <div className="text-center py-20 px-10 bg-slate-900/30 rounded-3xl border border-slate-800/50 max-w-md">
                  <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center border border-slate-700">
                    <svg className="w-12 h-12 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">Select a Scan</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">
                    Choose a scan from the history panel to view detailed vulnerability findings and AI-powered analysis
                  </p>
                </div>
              </div>
            )}
          </section>
        </div>
      </div>

      {/* Upload Modal Overlay */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div 
            className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
            onClick={() => setShowModal(false)}
          />
          <div className="relative bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl shadow-black/50 max-w-lg w-full mx-4 overflow-hidden">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 text-slate-500 hover:text-white p-2 rounded-lg hover:bg-slate-800 transition-colors z-10"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            <NewScanModal 
              onUpload={handleUpload} 
              onCancel={() => setShowModal(false)} 
            />
          </div>
        </div>
      )}

      {/* Finding Detail Drawer */}
      {selectedFinding && (
        <DetailDrawer 
          finding={selectedFinding} 
          onClose={() => setSelectedFinding(null)} 
        />
      )}
    </div>
  );
};

export default Dashboard;
