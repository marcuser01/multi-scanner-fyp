'use client';

import React, { useState } from 'react';
import axios from 'axios';
import ReactMarkdown from 'react-markdown';

export const DetailDrawer = ({ finding, onClose }) => {
  const [aiInsight, setAiInsight] = useState(finding.ai_insight);
  const [loading, setLoading] = useState(false);

  const getAIAnalysis = async () => {
    setLoading(true);
    try {
      const res = await axios.post(`http://localhost:8000/api/results/${finding.id}/ai-triage`);
      setAiInsight(res.data.insight);
    } catch (err) {
      setAiInsight("Failed to reach AI service. Please check your OpenRouter Key in Settings.");
    }
    setLoading(false);
  };

  const getSeverityColor = (severity) => {
    const s = severity?.toLowerCase();
    if (s === 'critical') return 'from-red-500 to-red-600';
    if (s === 'high') return 'from-orange-500 to-orange-600';
    if (s === 'medium') return 'from-yellow-500 to-amber-600';
    if (s === 'low') return 'from-emerald-500 to-emerald-600';
    return 'from-slate-500 to-slate-600';
  };

  const getSeverityBg = (severity) => {
    const s = severity?.toLowerCase();
    if (s === 'critical') return 'bg-red-500/10 border-red-500/30 text-red-400';
    if (s === 'high') return 'bg-orange-500/10 border-orange-500/30 text-orange-400';
    if (s === 'medium') return 'bg-yellow-500/10 border-yellow-500/30 text-yellow-400';
    if (s === 'low') return 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400';
    return 'bg-slate-500/10 border-slate-500/30 text-slate-400';
  };

  return (
    <div className="fixed top-0 right-0 h-full w-[520px] bg-slate-900 border-l border-slate-800 shadow-2xl shadow-black/50 z-40 flex flex-col animate-slide-in">
      {/* Severity Indicator Bar */}
      <div className={`h-1 bg-gradient-to-r ${getSeverityColor(finding.severity)}`} />
      
      {/* Header */}
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-bold uppercase tracking-wider mb-3 ${getSeverityBg(finding.severity)}`}>
              <span className={`w-2 h-2 rounded-full bg-current`} />
              {finding.severity} Severity
            </div>
            <h2 className="text-xl font-bold text-white leading-tight">
              {finding.title}
            </h2>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-lg text-slate-500 hover:text-white hover:bg-slate-800 transition-all"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Code Location */}
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
          <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 flex items-center gap-2">
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
            </svg>
            Code Location
          </h3>
          <code className="text-sm text-cyan-400 font-mono break-all">
            {finding.file_path}:{finding.line_number}
          </code>
        </div>

        {/* Scanner Description */}
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
          <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 flex items-center gap-2">
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            Scanner Description
          </h3>
          <p className="text-sm text-slate-300 leading-relaxed italic">
            "{finding.description}"
          </p>
        </div>

        {/* AI Triage Section */}
        <div className="mt-6">
          {!aiInsight ? (
            <button 
              onClick={getAIAnalysis}
              disabled={loading}
              className="w-full py-4 rounded-xl font-semibold transition-all duration-200 flex items-center justify-center gap-3 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white shadow-lg shadow-violet-500/25 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <>
                  <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  <span>AI Analysis in Progress...</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                  <span>Generate AI Insight</span>
                </>
              )}
            </button>
          ) : (
            <div className="bg-gradient-to-br from-violet-500/10 to-purple-500/10 rounded-2xl border border-violet-500/30 overflow-hidden">
              {/* AI Header */}
              <div className="px-5 py-4 bg-violet-500/10 border-b border-violet-500/20 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-lg shadow-violet-500/25">
                  <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">AI Triage Report</h3>
                  <p className="text-[10px] text-violet-300/70">Powered by LLM Analysis</p>
                </div>
              </div>
              
              {/* AI Content */}
              <div className="p-5 prose prose-invert prose-sm max-w-none">
                <ReactMarkdown
                  components={{
                    h1: ({node, ...props}) => <h1 className="text-lg font-bold text-white mt-4 mb-2 first:mt-0" {...props} />,
                    h2: ({node, ...props}) => <h2 className="text-base font-semibold text-white mt-4 mb-2" {...props} />,
                    h3: ({node, ...props}) => <h3 className="text-sm font-semibold text-slate-200 mt-3 mb-1" {...props} />,
                    p: ({node, ...props}) => <p className="text-sm text-slate-300 leading-relaxed mb-3" {...props} />,
                    ul: ({node, ...props}) => <ul className="text-sm text-slate-300 space-y-1 mb-3 list-disc pl-4" {...props} />,
                    ol: ({node, ...props}) => <ol className="text-sm text-slate-300 space-y-1 mb-3 list-decimal pl-4" {...props} />,
                    li: ({node, ...props}) => <li className="text-slate-300" {...props} />,
                    strong: ({node, ...props}) => <strong className="text-white font-semibold" {...props} />,
                    code: ({node, inline, ...props}) => 
                      inline 
                        ? <code className="text-xs bg-slate-800 text-cyan-400 px-1.5 py-0.5 rounded font-mono" {...props} />
                        : <code className="block text-xs bg-slate-800/80 text-cyan-400 p-3 rounded-lg font-mono overflow-x-auto border border-slate-700" {...props} />
                  }}
                >
                  {aiInsight}
                </ReactMarkdown>
              </div>

              {/* Regenerate Button */}
              <div className="px-5 pb-5">
                <button 
                  onClick={() => setAiInsight(null)} 
                  className="text-[10px] font-bold text-slate-500 uppercase tracking-widest hover:text-violet-400 transition-colors flex items-center gap-2 mx-auto"
                >
                  <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  Regenerate Analysis
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
