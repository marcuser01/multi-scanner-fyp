'use client';

import React, { useState } from 'react';

export const NewScanModal = ({ onUpload, onCancel }) => {
  const [file, setFile] = useState(null);
  const [config, setConfig] = useState('auto');
  const [taskName, setTaskName] = useState('');
  const [taskDescription, setTaskDescription] = useState('');

  const configs = [
    { id: 'auto', name: 'Auto Detect (Recommended)', icon: '⚡' },
    { id: 'owasp', name: 'OWASP Top 10', icon: '🛡️' },
    { id: 'audit', name: 'Security Audit (Deep)', icon: '🔍' },
    { id: 'python', name: 'Python Specific', icon: '🐍' },
    { id: 'secrets', name: 'Hardcoded Secrets', icon: '🔐' }
  ];

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 flex items-center justify-center mb-4">
          <svg className="w-7 h-7 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
          </svg>
        </div>
        <h2 className="text-2xl font-bold text-white mb-1">Launch New Triage</h2>
        <p className="text-slate-500 text-sm">Upload your project for vulnerability analysis</p>
      </div>
      
      <div className="space-y-5">
        {/* Task Name */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
            Task Name
          </label>
          <input 
            value={taskName}
            onChange={(e) => setTaskName(e.target.value)}
            className="w-full bg-slate-800/50 border border-slate-700 text-white px-4 py-3 rounded-xl focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all placeholder-slate-600"
            placeholder="e.g., Inventory System Audit"
          />
        </div>

        {/* Task Description */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
            App Context <span className="text-slate-600 font-normal">(Sent to AI)</span>
          </label>
          <textarea 
            value={taskDescription}
            onChange={(e) => setTaskDescription(e.target.value)}
            className="w-full bg-slate-800/50 border border-slate-700 text-white px-4 py-3 rounded-xl focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all resize-none h-24 placeholder-slate-600"
            placeholder="What does this app do? (e.g. Healthcare portal handling patient records)"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          {/* Ruleset Select */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Scanning Ruleset
            </label>
            <select 
              value={config} 
              onChange={(e) => setConfig(e.target.value)} 
              className="w-full bg-slate-800/50 border border-slate-700 text-white px-4 py-3 rounded-xl focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all appearance-none cursor-pointer"
              style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%2394a3b8'%3E%3Cpath strokeLinecap='round' strokeLinejoin='round' strokeWidth='2' d='M19 9l-7 7-7-7'/%3E%3C/svg%3E")`,
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'right 12px center',
                backgroundSize: '16px'
              }}
            >
              {configs.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          {/* File Upload */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Project Source
            </label>
            <label className="flex items-center justify-center gap-2 w-full bg-slate-800/50 border border-slate-700 border-dashed text-slate-400 px-4 py-3 rounded-xl cursor-pointer hover:border-cyan-500/50 hover:bg-slate-800 transition-all">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
              </svg>
              <span className="text-sm">
                {file ? file.name : 'Upload .ZIP'}
              </span>
              <input 
                type="file" 
                accept=".zip" 
                onChange={(e) => setFile(e.target.files[0])} 
                className="hidden"
              />
            </label>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-3 mt-8">
        <button 
          onClick={onCancel}
          className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 py-3 rounded-xl font-semibold transition-all"
        >
          Cancel
        </button>
        <button 
          onClick={() => onUpload(file, config, taskName, taskDescription)}
          disabled={!file}
          className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:from-slate-700 disabled:to-slate-700 text-white py-3 rounded-xl font-semibold shadow-lg shadow-cyan-500/25 disabled:shadow-none transition-all active:scale-95 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
          Start Triage
        </button>
      </div>
    </div>
  );
};
